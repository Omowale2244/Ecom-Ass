from fastapi import HTTPException
from schema.customer import customers, CustomerCreate
class CustomerServices:

    @staticmethod
    def validate_username(payload: CustomerCreate):
        username = payload.username
        for customer in payload.customers:
            if customer.username == username:
                raise HTTPException(status_code=400, detail="The customer with inputed username already exist")
            return payload